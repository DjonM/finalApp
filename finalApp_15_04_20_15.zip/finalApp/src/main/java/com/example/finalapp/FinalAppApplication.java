package com.example.finalapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalAppApplication.class, args);
    }

}
