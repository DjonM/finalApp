package com.example.finalapp.controllers;

import com.example.finalapp.models.Category;
import com.example.finalapp.models.Image;
import com.example.finalapp.models.Product;
import com.example.finalapp.repositories.CategoryRepository;
import com.example.finalapp.repositories.OrderRepository;
import com.example.finalapp.services.OrderService;
import com.example.finalapp.services.PersonService;
import com.example.finalapp.services.ProductService;
import com.example.finalapp.services.StatusService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Controller
public class AdminController {

    private final ProductService productService;
private  final StatusService statusService;
    @Value("${upload.path}")
    private String uploadPath;

    private final CategoryRepository categoryRepository;
    private final OrderService orderService;
private final OrderRepository orderRepository;
private final PersonService personService;


    public AdminController(ProductService productService, StatusService statusService, CategoryRepository categoryRepository, OrderService orderService, OrderRepository orderRepository, PersonService personService) {
        this.productService = productService;
        this.statusService = statusService;
        this.categoryRepository = categoryRepository;
        this.orderService = orderService;
        this.orderRepository = orderRepository;
        this.personService = personService;
    }

    @GetMapping("admin/product/add")
    public String addProduct(Model model){
        model.addAttribute("product", new Product());
        model.addAttribute("category", categoryRepository.findAll());
        return "product/addProduct";
    }

    @PostMapping("/admin/product/add")
    public String addProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult, @RequestParam("file_one")MultipartFile file_one, @RequestParam("file_two")MultipartFile file_two, @RequestParam("file_three")MultipartFile file_three, @RequestParam("file_four")MultipartFile file_four, @RequestParam("file_five")MultipartFile file_five, @RequestParam("category") int category, Model model) throws IOException {
        Category category_db = (Category) categoryRepository.findById(category).orElseThrow();
        System.out.println(category_db.getName());
        if(bindingResult.hasErrors()){
            model.addAttribute("category", categoryRepository.findAll());
            return "product/addProduct";
        }

        if(file_one != null){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_one.getOriginalFilename();
            file_one.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);

        }

        if(file_two != null){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_two.getOriginalFilename();
            file_two.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(file_three != null){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_three.getOriginalFilename();
            file_three.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(file_four != null){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_four.getOriginalFilename();
            file_four.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(file_five != null){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_five .getOriginalFilename();
            file_five .transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }
        productService.saveProduct(product, category_db);
        return "redirect:/admin";
    }


    @GetMapping("/admin")
    public String admin(Model model)
    {
        model.addAttribute("products", productService.getAllProduct());
        model.addAttribute("ord", orderService.getAllOrder());
        return "admin";
    }

    @GetMapping("admin/product/delete/{id}")
    public String deleteProduct(@PathVariable("id") int id){
        productService.deleteProduct(id);
        return "redirect:/admin";
    }

    @GetMapping("admin/product/edit/{id}")
    public String editProduct(Model model, @PathVariable("id") int id){
        model.addAttribute("product", productService.getProductId(id));
        model.addAttribute("category", categoryRepository.findAll());
        return "product/editProduct";


    }

    @PostMapping("admin/product/edit/{id}")
    public String editProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult, @PathVariable("id") int id, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("category", categoryRepository.findAll());
            return "product/editProduct";
        }
        productService.updateProduct(id, product);
        return "redirect:/admin";
    }

    @GetMapping("/admin/order/new_status/{id}")
    public String getNewStatus(@PathVariable ("id") int id, Model model)
    {
        model.addAttribute("order_new", orderService.getOrderId(id));
        model.addAttribute("orders", orderService.getAllOrder());
        model.addAttribute("status", statusService.getAllStatus());
        return "new_status";
    }

    @GetMapping("/order/search")
    public String productSearch(@RequestParam("search") String search, Model model) {
if (!search.equals(""))
{

        model.addAttribute("value_search", orderRepository.findByTitle(search));
        model.addAttribute("products", productService.getAllProduct());
        model.addAttribute("ord", orderService.getAllOrder());


}else {
    model.addAttribute("products", productService.getAllProduct());
    model.addAttribute("ord", orderService.getAllOrder());
}


        return "/admin";

    }

    @PostMapping("admin/order/edit/{id}")
    public String editOrder(@ModelAttribute("status") String status, @PathVariable("id") int id, Model model){
           model.addAttribute("status", statusService.getAllStatus());


               orderService.updateOrder(orderService.getOrderId(id),status);



        return "redirect:/admin";
    }


    @GetMapping("/admin/users")
    public String findAllUsers(Model model) {
       model.addAttribute("persons",personService.getAllPerson());


        return "/admin_user";

    }


    @GetMapping("/admin/users/edit/{id}")
    public String findAllUsers(@PathVariable("id") int id, Model model) {
        model.addAttribute("persons",personService.getPersonId(id));


        return "/admin_users_edit";

    }

    @PostMapping("/admin/users/edit/{id}")
    public String editUsers(@ModelAttribute("status_person") String statusPerson, @PathVariable("id") int id, Model model) {


        personService.updatePerson(personService.getPersonId(id), statusPerson);


        return "redirect:/admin";

    }


}
